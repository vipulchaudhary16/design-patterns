package memento.article;

public class Memento {
    String article;

    public Memento(String article) {
        this.article =article;
    }

    public String getArticle() {
        return article;
    }
}
